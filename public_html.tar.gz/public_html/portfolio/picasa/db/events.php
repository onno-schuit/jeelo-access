<?php

$handlers = array (
    'user_deleted' => array (
         'handlerfile'      => '/portfolio/picasa/lib.php',
         'handlerfunction'  => 'portfolio_picasa_user_deleted',
         'schedule'         => 'cron',
         'internal'         => 0,
     ),
);


