<?php
// FILENAME: mod/planner/class.jeelo.php
include_once("{$CFG->dirroot}/local/soda/class.soda.php");

class Jeelo extends soda {

} // class Jeelo