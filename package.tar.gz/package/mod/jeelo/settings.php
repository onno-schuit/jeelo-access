<?php
  /*
defined('MOODLE_INTERNAL') || die;

require_once($CFG->dirroot . '/mod/assign/adminlib.php');

$ADMIN->add('modules', new admin_category('jeeloplugins',
                "TeST", !$module->visible));
  */