<?php

require_once('../../config.php');
require_once('./lib.php');

$App = new Soda2($config);

$App->render();
