<?php
  // example contents for lang/en/jeelo.php
  $string['modulename'] = "Paneel Individuele Toegang";
  $string['modulenameplural'] = 'Panelen Individuele Toegang';
  $string['modulename_help'] = 'Gebruik deze module om de toegang tot activiteiten voor specifieke leerlingen te (ont)sluiten';
  $string['newmodulefieldset'] = 'Custom example fieldset';
  $string['newmodulename'] = 'Paneel Individuele Toegang';
  $string['newmodulename_help'] = 'This is the content of the help tooltip associated with the newmodulename field. Markdown syntax is supported.';
  $string['newmodule'] = 'Paneel Individuele Toegang';
  $string['pluginadministration'] = 'Beheer Paneel Individuele Toegang';
  $string['pluginname'] = 'Paneel Individuele Toegang';
?>
