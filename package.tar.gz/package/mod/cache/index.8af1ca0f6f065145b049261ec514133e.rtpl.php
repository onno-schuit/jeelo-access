<?php if(!class_exists('raintpl')){exit;}?>qw
